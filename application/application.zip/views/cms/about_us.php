<div class="contentWrapper cmsContent">
	
	<h2>Welcome to NANDALAL GHOSH B.T. COLLEGE</h2>
	<p>We are affiliated to West Bengal State University. Barasat (formerly affiliated to Calcutta University) and recognized
by the National Council. for Teacher Education (NCTE), was established in 1968 under the terms of an endowment
dated 17th May, 1968 made by the benevolent Donors Late Gostha Behari Ghosh and Late Amarendra Nath Ghosh
for spread of education to meet the social, academic and national needs.</p>

	<h2>Our Mission & Vision</h2>
	<p>Teachers are friend, philosopher and guide. Trainees are to be developed in this respect. Teachers Training is a
training of discipline in life. Trainees are to be disciplined in every respect. Value education, National integration and
International understanding bring National harmony in the world. Trainees are to cultivate these in positive attitude.
Teaching depends on standard qualities of the good teachers. Trainees are to be developed for achieving this
standard. Teachers are the architect of a better future for the nation. Trainees are to develop the qualities amiable
disposition with sympathy and patience; capacity to create interest in the pupil for lesson; model personality, will
power, ability of absolutely impartial leadership.
Demonstration of the spirit of Cooperation
and teacher like attitude, which are the tradition in the College ; would
be expectation from each and every trainee.</p>

	<h2>College Governing Body</h2>
	<p>The College Administration is governed by a body
		<ul>
			<li><b>Dr.Gobinda Chandra Sadhukhan.</b> (President )</li>
			<li><b>Dr.Chaitanya Mondal.</b> (TeacherinCharge)</li>
			<li><b>Dr.Remesh Barman.</b> (Member )</li>
			<li><b>Dr.Soma Nandi.</b> (Member )</li>
			<li><b>Sri Moumita Chowdhury.</b> (Member )</li>
			<li><b>Dr.Amarendra Nath Chatterjee.</b> (Member )</li>
			<li><b>Dr.Anath Bandhu Gayen.</b> (Member )</li>
			<li><b>Dr.Dilip Kumar Bhattacharya.</b> (Member )</li>
			<li><b>Dr.Shanta Moulik.</b> (Teachers' Representative )</li>
			<li><b>Smt.Sriparna Bagchi.</b> (Teachers' Representative )</li>
			<li><b>Dr.Surapati Pramanik.</b> (Teachers' Representative )</li>
			<li><b>Sri Syamal Ray.</b> (NTS Representative )</li>
			<li><b>Sri Rajkumar Dom.</b> (NTS Representative )</li>
			<li><b>Sri Biplab Mondal.</b> (NTS Representative )</li>
		</ul>
</p>

	
<h2>Practice Teaching</h2>
<p>Practice Teaching is held generally in the schools surrounding the college. At least 40 lessons on two method
subjects (20+20) are to be given. Before going to the school for practice teaching, trainees will have to take
simulation teaching.</p>

<h2>Examination</h2>
<p>
	<ul>
		<li>CollegeTest Examination will be held before final examination (semistar wise)</li>
		<li>To sit for the above Examination is compulsory.</li>
		<li>Periodical Examinations are held by different department.</li>
		<li>Final Examination (Semester system) will generally be held as per direction of W.B.S.U. Barasat.</li>
	</ul>
</p>

<h2>Session</h2>
<p>The session commences on the 1st July and continues upto the 15th May of the next year.</p>

<h2>College Hostel</h2>
<p>The College follows the Holiday list of West Bengal State University, Barasat and Govt. of W.B. approved for Govt.
aided college.</p>

<h2>List of Holidays</h2>
<p>The College has hostel for male trainees. To make the College as fully residential another hostel for female trainees
will be proposed to construct near future</p>


</div>