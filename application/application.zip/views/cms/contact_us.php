<div class="contentWrapper cmsContent">
	<h2>Nandalal Ghosh B.T. College</h2>
	<p class="noMargin">(033) 2580 1826</p>
	<p class="noMargin">Panpur</p>
	<p class="noMargin"> PO: Narayanpur</p>
	<p class="noMargin"> Dist: 24 Parganas(N)</p>
	<p class="noMargin"> PIN:743126</p>
	<p class="noMargin"><a href="mailto:contact@ngbtc.org">contact@ngbtc.org</a></p>

	<h2>Reach us At</h2>
	<iframe width="680" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=NANDALAL+GHOSH+B.T.+COLLEGE&amp;aq=&amp;sll=22.864787,88.431015&amp;sspn=0.375818,0.617294&amp;ie=UTF8&amp;hq=NANDALAL+GHOSH+B.T.+COLLEGE&amp;hnear=&amp;t=m&amp;ll=22.759087,88.436165&amp;spn=0.071233,0.116558&amp;z=13&amp;iwloc=A&amp;output=embed"></iframe>
	<div class="gap10"></div>
	<a class="btn btn-custom btn-sm" target="_blank" href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=NANDALAL+GHOSH+B.T.+COLLEGE&amp;aq=&amp;sll=22.864787,88.431015&amp;sspn=0.375818,0.617294&amp;ie=UTF8&amp;hq=NANDALAL+GHOSH+B.T.+COLLEGE&amp;hnear=&amp;t=m&amp;ll=22.759087,88.436165&amp;spn=0.071233,0.116558&amp;z=13&amp;iwloc=A" >View Larger Map</a>
</div>
