<div class="contentWrapper cmsContent">
	<h2>Teaching Staff</h2>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Dr. Chaitanya Mondal</b>, Teacher-in-charge,</p>
	<p>B.Sc. (Hons.) Physics, M.Sc. (Education) B.Ed, Ph.D. (Education).</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Dr. Shanta Moulik</b>, Asst. Professor,</p>
	<p> M.A. (Bengali), B.Ed. Ph.D. (Bengali), M.Ed. </p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Smt. Sreeparna Bagchi (Biswas)</b>, Associate Professor</p>
	<p>  M.A.(History.) B.Ed. , M.Phill (History)  M.Ed.  </p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Dr. Surapati Pramanik</b>, Asst. Professor </p>
	<p>  M.Sc. (Mathematics) B.T., Ph.D. (Mathematics) M.Ed., SCIR-UGC NET  (Mathematics), UGC NET (Education)</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Smt. Nabanita Banerjee (Das)</b>, (Contractual Fulltime) </p>
	<p> M.A. (English), B.Ed.  M.A. (Education)  UGC.-NET</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Sri Ananta Kr. Mondal</b>, (Guest Lecturer), (W.Edu) </p>
	<p>  M.A. (History), B.Ed., M.Ed.</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Sri Parimal Ghosh</b>, (Guest Lecturer) </p>
	<p>  M.A. (Pol. Sc) B.Ed.</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Mrs. Arunima Ghosh</b>, (Guest Lecturer) </p>
	<p>  M.A. (Sanskrit) B.Ed., M.Ed.</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Md. Mahfuzur Rahaman Mullick </b>, (Guest Lecturer) </p>
	<p>  M.Com., B.Ed.</p>
	
	<div class="gap10"></div>
	<p class="noMargin"><b>Sri Satanjib Chakraborty </b></p>
	<p>M.Sc. (Computer Science), M.A. (Education)</p>

	<p>(N.B.This current List may be changed during the session 2014-2015)</p>

	<h2>Technical Support Staff</h2>
	
	<div class="gap10"></div>
	<p class="noMargin">1.  <b>Sri Arun Mahato, Librarian</b> (Contactual Full Time) </p>
	<p> M.Li.Sc. Dip. in Computer.</p>
	
	<div class="gap10"></div>
	<p class="noMargin">2.  <b>Sri Indranil Ghosh</b>, (Technician)  (Contractual Full Time) BCA. </p>
	
	<div class="gap10"></div>
	<p class="noMargin">3.  <b>Sri Krishnu Dey</b> : Library Assistant  (Contractual Full Time) Madhyamik.</p>
	
	<div class="gap10"></div>
	<p class="noMargin">4. <b>Sri Barun Kumar Samanta</b>, Laboratory Assistant (Contracual Part Time) B.Sc. </p>
	<div class="gap10"></div>

	<p>   (N.B. This current List may be changed during the session 2014-2015) </p>

	<h2>Administrative Staff</h2>
	
	<div class="gap10"></div>
	<p class="noMargin">1.<b> Sri Shyamal Ray</b>, Head Clerk,  </p>
	<p> B.Com., Diploma in Computer.</p>
	
	<div class="gap10"></div>
	<p class="noMargin">2. <b>Sri Sanjay Sardar</b>, Accountant (Contractual Fulltime)</p>
	
	<div class="gap10"></div>
	<p class="noMargin">3. <b>Sri. Sukumar Bhangar</b> : Store-Keeper (Guard), Class - VIII</p>
	
	<div class="gap10"></div>
	<p class="noMargin">4. Attendant / Helper / Support Staff : Vacant </p>
	
	<div class="gap10"></div>
	<p class="noMargin">5. <b>Sri. Arun Trafder </b>: Attendant / Helper / Support Staff, Class - IV</p>
	
	<div class="gap10"></div>
	<p class="noMargin">6. <b>Sri Raj Kumar Dom</b> : Sweeper, Functionally Literate, </p>
	
	<div class="gap10"></div>
	<p class="noMargin">7.<b> Smt. Indrani Ghosh</b> : Lady Attendant (Contractual Fulltime)  H.S. </p>
	<div class="gap10"></div>

	<p> (N.B.This current List may be changed during the session 2014-15) </p>

</div>