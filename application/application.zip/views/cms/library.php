<div class="contentWrapper cmsContent">
	<h2>College Library</h2>
	<p>The library has two sections:</p>
	<p>i)  Lending</p>
	<p>ii)  Reading</p>
	<p>Both the sections will be managed by the library department according to the rules and regulations to be framed by the department and approved by the Teacher-in-charge.</p>
</div>