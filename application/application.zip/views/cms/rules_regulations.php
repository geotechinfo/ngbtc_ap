<div class="contentWrapper cmsContent">
	<h2>College Hours</h2>
	<p> The College Office remain open from 9.45 A.M. to 5 P.M. Classes are generally held from 11A.M. to 5 P.M. </p>
	<p>The College library remains open from 11. A.M. to 4.30 P.M. Class hours, office hours and library hours may be changed for the academic interest and purpose of the course. As it is a training college, trainees have to stay for a longer period if required and they are to adjust with the college hours for development of the college. </p>
	<h2>Attendance</h2>
	<p>Trainees must attend the college regularly and timely. They are to put their signature in the attendance register mentioning the time of arrival. When the classes are over, the trainees are to put their signature in the register giving the time of departure. If any body wants to leave the college earlier, he/she has to inform the Teacher-in-charge in writing before doing so. Any violation of this system is a serious break of discipline. </p>
	<p>To be Collegiate, trainees are to attend 75% of the Lectures delivered on each subject. If they fail to attend 60% of the Lecture delivered, they will be discollegiate, and will not be qualified for appearing at the Final Examination. Attendance in Lectures more than 60%, but less then 75% will be treated as non - collegiate. This rule will be strictly followed. </p>
	<h2>Dresses</h2>
	<p>Trainees must have to wear proper uniform in each day otherwise no attendance will be given on that day.</p>
	<table class="cmsTable table">
		<tr>
			<td>Female : </td>
			<td>Shirt & Pant / Dhuti & Panjabi</td>
		</tr>
		<tr>
			<td>Male : </td>
			<td>Saree / Churidar</td>
		</tr>
	</table>
	<h2>Observance</h2>
	<p>The following days are to be observed with proper importance. </p>
	<p class="noMargin"> 1.  Independence Day</p>
	<p class="noMargin"> 2.  College Foundation Day</p>
	<p class="noMargin"> 3.  Teacher’s Day</p>
	<p class="noMargin"> (Birth day of Dr. S. Radhakrishnan)</p>
	<p class="noMargin"> 4.  Birth day of Netaji Subahs Chandra Bose</p>
	<p class="noMargin"> 5.  University foundation Day</p>
	<p class="noMargin"> 6.  Republic Day</p>
	<div class="gap10"></div>
	<p>(Besides these, other days of National importance in the session are duly observed). </p>
</div>